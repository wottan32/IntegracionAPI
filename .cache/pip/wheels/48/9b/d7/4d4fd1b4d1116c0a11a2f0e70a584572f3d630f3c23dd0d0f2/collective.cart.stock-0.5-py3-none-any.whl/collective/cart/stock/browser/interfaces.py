from zope.interface import Interface


class ICollectiveCartStockLayer(Interface):
    """Marker interface for browserlayer."""
