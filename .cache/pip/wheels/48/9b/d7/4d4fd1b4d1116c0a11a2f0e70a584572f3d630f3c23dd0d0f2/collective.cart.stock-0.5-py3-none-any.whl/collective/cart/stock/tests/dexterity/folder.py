from plone.supermodel.model import Schema


class FolderSchema(Schema):
    """Schema for test folder"""
