Changelog
---------

0.5 (2013-10-28)
================

- Moved test packages to extras_require. [taito]
- Removed dependency from five.grok. [taito]
- Tested with Plone-4.3.2. [taito]

0.4 (2013-02-02)
================

- Added finnish translation for domain: plone.dexterity.

0.3 (2013-01-23)
================

- Fixed subscriber while pasting stock. [taito]
- Integrated Travis CI. [taito]

0.2 (2012-09-19)
================

- Added Finnish translations. [taito]

0.1 (2012-09-01)
================

- Initial release. [taito]
