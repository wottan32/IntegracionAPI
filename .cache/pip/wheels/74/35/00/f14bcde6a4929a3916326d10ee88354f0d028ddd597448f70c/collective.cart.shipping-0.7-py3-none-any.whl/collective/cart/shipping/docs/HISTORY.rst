Change log
----------

0.7 (2013-10-28)
================

- Move test packages to extras_require. [taito]
- Remove dependency from five.grok. [taito]
- Move cart related content types to order related ones. [taito]
- Prepare to update AT content type to Dexterity one. [taito]
- Test with Plone-4.3.2. [taito]

0.6 (2013-03-26)
================

- Refactored implementation of vocabulary: "collective.cart.shipping.rates". [taito]
- Updated field: vat from string to float. [taito]

0.5 (2013-03-07)
================

- Removed orig_uuid for session cart. [taito]
- Added Travis CI integration. [taito]
- Updated translations. [taito]
- Added case when shipping_fee is not function. [taito]

0.4.1 (2012-09-20)
==================

- Added ShippingMethod and collective.cart.shipping.CartShippingMethod to types_not_searched and metaTypesNotToList properties. [taito]

0.4 (2012-09-19)
================

- Tested with Plone-4.2.1. [taito]
- Added Finnish translations. [taito]

0.3 (2011-09-24)
================

- End of support for Plone-3.x.
- License updated from GPL to BSD.

0.2.0 (2011-04-25)
==================

- Refactored for plug-in.

0.1.0 (2011-04-21)
==================

- Initial release.
