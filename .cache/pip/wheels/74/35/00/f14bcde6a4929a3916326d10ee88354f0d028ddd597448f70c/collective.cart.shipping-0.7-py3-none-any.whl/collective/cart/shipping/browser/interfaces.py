from zope.interface import Interface


class ICollectiveCartShippingLayer(Interface):
    """Marker interface for browserlayer."""
