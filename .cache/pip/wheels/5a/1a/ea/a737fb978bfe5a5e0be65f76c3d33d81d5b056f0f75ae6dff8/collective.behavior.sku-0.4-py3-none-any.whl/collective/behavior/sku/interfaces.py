from collective.behavior.sku.schema import SKUSchema


class ISKU(SKUSchema):
    """Interface for behavior: SKU"""
