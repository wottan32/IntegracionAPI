Changelog
---------

0.4 (2014-02-13)
================

- Update to bootstrap2. [taito]
- Move SKU validator to tests. [taito]

0.3 (2013-10-28)
================

- Separated schema from attributes and methods. [taito]
- Moved test packages to extras_require. [taito]
- Removed dependency from five.grok. [taito]
- Tested with Plone-4.3.2. [taito]

0.2 (2012-11-04)
================

- Tested with Plone-4.2.2. [taito]

0.1 (2012-10-15)
================

- Initial release. [taito]
