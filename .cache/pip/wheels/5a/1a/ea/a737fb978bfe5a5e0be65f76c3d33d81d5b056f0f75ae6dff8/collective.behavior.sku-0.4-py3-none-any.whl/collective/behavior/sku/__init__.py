from zope.i18nmessageid import MessageFactory

_ = MessageFactory('collective.behavior.sku')
