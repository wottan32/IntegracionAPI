from plone.supermodel.model import Schema


class ICFolderSchema(Schema):
    """Generic container content type for versatile content."""
