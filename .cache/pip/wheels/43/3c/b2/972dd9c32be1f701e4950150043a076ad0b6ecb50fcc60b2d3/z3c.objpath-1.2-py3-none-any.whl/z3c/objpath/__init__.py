from z3c.objpath import path as _path  # noqa: F401

from z3c.objpath.path import path  # noqa: F401
from z3c.objpath.path import resolve  # noqa: F401
