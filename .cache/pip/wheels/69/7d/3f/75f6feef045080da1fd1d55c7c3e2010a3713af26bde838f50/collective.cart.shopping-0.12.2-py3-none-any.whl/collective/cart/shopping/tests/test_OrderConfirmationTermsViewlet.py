# from collective.cart.shopping.browser.viewlet import OrderConfirmationTermsViewlet

import unittest


class OrderConfirmationTermsViewletTestCase(unittest.TestCase):
    """TestCase for OrderConfirmationTermsViewlet"""

    def test(self):
        pass

    # def test_subclass(self):
    #     from collective.cart.shopping.browser.viewlet import BaseShoppingSiteRootViewlet
    #     from collective.cart.shopping.browser.base import Message
    #     self.assertTrue(issubclass(OrderConfirmationTermsViewlet,
    #         (BaseShoppingSiteRootViewlet, Message)))

    # def test_name(self):
    #     self.assertEqual(getattr(OrderConfirmationTermsViewlet, 'grokcore.component.directive.name'),
    #         'confirmation-terms')

    # def test_template(self):
    #     self.assertEqual(getattr(OrderConfirmationTermsViewlet, 'grokcore.view.directive.template'),
    #         'confirmation-terms')

    # def test_viewletmanager(self):
    #     from collective.cart.shopping.browser.viewlet import TermsViewletManager
    #     self.assertEqual(getattr(OrderConfirmationTermsViewlet, 'grokcore.viewlet.directive.viewletmanager'), TermsViewletManager)
