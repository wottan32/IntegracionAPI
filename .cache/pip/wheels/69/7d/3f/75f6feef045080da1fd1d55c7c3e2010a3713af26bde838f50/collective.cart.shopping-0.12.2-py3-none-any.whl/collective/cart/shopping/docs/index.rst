.. include:: README.rst

More contents
-------------

.. toctree::
    :maxdepth: 2

    INSTALL.rst
    HISTORY.rst
    CONTRIBUTORS.rst
    CREDITS.rst
    LICENSE.rst

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
