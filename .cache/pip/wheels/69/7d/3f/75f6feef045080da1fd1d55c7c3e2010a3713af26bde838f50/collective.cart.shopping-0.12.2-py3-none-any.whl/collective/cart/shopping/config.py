LOCALES = (
    ('fi', 'fi_FI'),)
