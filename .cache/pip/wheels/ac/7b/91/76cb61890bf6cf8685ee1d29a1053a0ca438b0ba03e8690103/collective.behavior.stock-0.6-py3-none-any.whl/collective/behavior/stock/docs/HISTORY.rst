Changelog
---------

0.6 (2013-10-28)
====================

- Updated sort order for stock. [taito]
- Separated schema from attributes and methods. [taito]
- Moved test packages to extras_require. [taito]
- Removed dependency from five.grok. [taito]
- Tested with Plone-4.3.2. [taito]

0.5 (2013-02-07)
================

- Added method: stocks which returns catalog brains of stocks. [taito]

0.4 (2013-02-04)
================

- Update methods: sub_stock and add_stock to avoid ValueError. [taito]

0.3 (2013-02-03)
================

- Defined initial_stock. [taito]
- Integrated Travis CI. [taito]

0.2.1 (2012-09-24)
==================

- Finnish translations updated. [taito]

0.2 (2012-09-17)
================

- Finnish translations added. [taito]

0.1 (2012-09-01)
================

- Initial release. [taito]
