Changelog
---------

0.3.1 (2015-06-25)
==================

- Fix test. [taito]

0.3 (2013-10-28)
================

- Separate schema from attributes and methods. [taito]
- Move test packages to extras_require. [taito]
- Remove dependency from five.grok. [taito]
- Test with Plone-4.3.2. [taito]
- Add Travis CI integration. [taito]

0.2.2 (2012-11-04)
==================

- Update method: _set_date to cover edge case when value is None. [taito]
- Test with Plone-4.2.2. [taito]

0.2.1 (2012-09-24)
==================

- Update schema to include vat. [taito]

0.2 (2012-09-17)
================

- Add Finnish translations. [taito]

0.1 (2012-08-28)
================

- Initial release. [taito]
