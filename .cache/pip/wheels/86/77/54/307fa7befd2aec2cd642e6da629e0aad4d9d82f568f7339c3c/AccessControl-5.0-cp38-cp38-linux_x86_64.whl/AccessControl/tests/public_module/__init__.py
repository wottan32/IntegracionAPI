# test module, public

from Acquisition import aq_base  # Foil the old ZopeSecurityPolicy # NOQA: F401


def pub():
    pass
