Change log
----------

0.3 (2013-10-28)
====================

- Separated schema from attributes and methods. [taito]
- Moved test packages to extras_require. [taito]
- Removed dependency from five.grok. [taito]
- Tested with Plone-4.3.2. [taito]

0.2.1 (2012-09-24)
==================

- Finnish translations fixed. [taito]

0.2 (2012-09-17)
================

- Finnish translations added. [taito]

0.1 (2012-09-01)
================

- Initial release. [taito]
