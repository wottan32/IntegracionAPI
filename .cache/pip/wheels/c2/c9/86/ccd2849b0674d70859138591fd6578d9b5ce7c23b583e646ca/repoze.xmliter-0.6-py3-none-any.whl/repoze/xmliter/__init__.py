from repoze.xmliter.decorator import lazy
