Changelog
---------

0.4.2 (2015-07-14)
==================

- Migrate Travis CI to container-based. [taito]
- Move Products.CMFPlacefulWorkflow dependency to test. [taito]

0.4.1 (2015-06-25)
==================

- Fix test. [taito]

0.4 (2013-10-28)
================

- Added helper method to get money. [taito]
- Separated schema from attributes and methods. [taito]
- Removed dependency to five.grok. [taito]
- Tested with Plone-4.3.2. [taito]

0.3.1 (2013-04-10)
==================

- Moved test packages to extras_require. [taito]
- Tested with Plone-4.2.5. [taito]

0.3 (2013-02-07)
================

- Added column: price to catalog metadata. [taito]
- Tested with Plone-4.2.4. [taito]
- Integrated to Travis CI. [taito]

0.2.1 (2012-11-04)
==================

- Updated method: _set_price to cover edge case when value is None. [taito]
- Tested with Plone-4.2.2. [taito]

0.2 (2012-09-17)
================

- Finnish translations added. [taito]

0.1 (2012-08-28)
================

- Initial release. [taito]
