from plone.supermodel.model import Schema


class ITestFolderSchema(Schema):
    """Schema interface for TestFolder"""
