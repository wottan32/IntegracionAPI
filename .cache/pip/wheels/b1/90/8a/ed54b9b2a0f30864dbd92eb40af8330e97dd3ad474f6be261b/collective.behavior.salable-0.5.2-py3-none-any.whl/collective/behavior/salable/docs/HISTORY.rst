Changelog
---------

0.5.2 (2015-07-14)
==================

- Migrate Travis CI to container-based. [taito]
- Move Products.CMFPlacefulWorkflow dependency to test. [taito]

0.5.1 (2015-06-25)
==================

- Fix test. [taito]

0.5 (2013-10-28)
================

- Separated schema from attributes and methods. [taito]
- Tested with Plone-4.3.2. [taito]
- Moved test packages to extras_require. [taito]
- Removed dependency from five.grok. [taito]

0.4 (2013-03-09)
================

- Covered tests and tested with Plone-4.2.5. [taito]
- Added Travis CI integration. [taito]

0.3 (2012-11-04)
================

- Added salable to catalog index and metadata. [taito]
- Tested with Plone-4.2.2. [taito]

0.2 (2012-09-17)
================

- Finnish translations added. [taito]

0.1 (2012-08-28)
================

- Initial release. [taito]
