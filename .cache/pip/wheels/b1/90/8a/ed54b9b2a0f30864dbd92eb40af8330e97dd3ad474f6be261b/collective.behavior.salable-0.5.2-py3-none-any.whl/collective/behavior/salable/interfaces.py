from collective.behavior.salable.schema import SalableSchema


class ISalable(SalableSchema):
    """Interface for behavior: Salable"""
